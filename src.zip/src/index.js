const express = require('express');
const app = express();
const json = require('./prueba.json');
const bodyParser = require('body-parser');

app.set('port',3000);
app.use(bodyParser.json());

/* Metodos http
Get
Post
Put
Delete
*/

const middleware = (req, res, next) => {
    console.log('Aqui comienza un middleware');
};

app.get('/',(req, res) => {
    return res.send('El API se esta ejecutando');
});

//GET

app.get('/obterinfo', (req, res) => {
    return res.send(json);
});

app.get('/getById/:id?', (req, res) => {
    const id = req.params.id;
    let response = null;


    if (id){
        json.filter(element => {
        if(element.id == id){
            response = element
        }
    });

    return res.send(response);
}

    return res.send(json);
});

//POSt

app.post('/addItem', (req, res) =>{
    const body = req.body;

    json.push(body);

    return res.send(json);
});

//PUT

app.put('/updateItem/:id', (req,res) =>{
    const id = req.params.id;
    const body = req.body;
    let response = null;

    json.filter(element =>{
        if(element.id == id){
            element.description = body.description;
            element.price = body.price;
            element.count = body.count;
        }
    });
    return res.send(json);
});

app.delete('/deleteItem/:id', (req,res) => {
    const id = req.params.id;

    json.filter((element, index) => {
        if (element.id == id){
            json.splice(index, 1);
        }
    });

    return res.send(json);
});

app.listen(app.get('port'), () => {
    console.log('Hola server');
});